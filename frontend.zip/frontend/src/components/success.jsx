import React from "react";

const Success = () => {
  return <div>signup successful</div>;
};

export default Success;
