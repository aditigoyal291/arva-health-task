import LoginForm from "@/components/login-form";
import React from "react";

const Signup = () => {
  return (
    <div className="flex min-h-screen items-center justify-center">
      <div className="">
        <LoginForm />
      </div>
    </div>
  );
};

export default Signup;
