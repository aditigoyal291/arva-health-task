import React from "react";
import Notfound from "./not-found";
const About = () => {
  return <div>About</div>;
};

export default About;
